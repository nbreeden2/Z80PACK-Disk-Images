#include <stdio.h>
/*#include "dazzler.h"*/

/* Smaller values of CLEARVALUE will clear the screen more often  */
/* Suggest to keep it between 32700 and 32767 (it's a signed int) */
#define CLEARVALUE 32750

main()
{
  int  x;   /* current x pixel location    */
  int  y;   /* current y pixel location    */
  int  c;   /* current color               */
  int  n;   /* used to drive plotting      */
  int  l;   /* while true keep looping     */
  int  f;   /* level to change plot color  */
  char k;   /* byte read from the keyboard */
    
  printf("\n\nPress X to exit the program\n\n");
  printf("Press '[' to change FG color quicker,\n");
  printf(" or press ']' for less often.\n\n");
    
  srand(0);  /* randomize the rand() root */
  dzopen();  /* enable the dazzler        */

  /* and now we do something */
  x=rand()  % 32;  /* 0 to 31 or 32 positions */
  y=rand()  % 32;  /* 0 to 31 or 32 positions */
  c=(rand() %  8) + 8;
  f=(rand() % 32);

  dzbackground(c & 0x07);

  l = 1; /* loop until X is pressed */
  do
  {
    n = rand();
    if (n > CLEARVALUE)
    {
      dzbackground(c & 0x07); /* dzclear(); */
    }
    
    n = n % 6;
    switch(n)
    {
      case 0: x++; break;
      case 1: x--; break;
      case 2: y++; break;
      case 3: y--; break;
      if ((rand() & 0x1F) >= f)
      {
        if (n==4){c++;}
        if (n==5){c--;}
      }
    }

    x &= 0x1F;  /* if (x>31) x=31; */
    y &= 0x1F;  /* if (y>31) y=31; */

    if (c>15) c=(rand() % 8) + 8;
    if (c< 8) c=(rand() % 8) + 8;

    dzsetpixel(   x,   y,c);  /* upper left  quad */
    dzsetpixel(63-x,63-y,c);  /* lower right quad */
    dzsetpixel(63-x,   y,c);  /* lower left  quad */
    dzsetpixel(   x,63-y,c);  /* upper right quad */

    if (kbhit())
    {
      k = getchar();
      if ((k == 'x') || (k == 'X')) { l=0; }
      if  (k == '[') {f--; if (f< 0) f= 0; printf("%d ",f);}
      if  (k == ']') {f++; if (f>31) f=31; printf("%d ",f);} 
    }
  }
  while(l);

  dzclose();
}


