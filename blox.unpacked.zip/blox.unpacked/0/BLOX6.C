#include <stdio.h>
/*#include "dazzler.h"*/

/* Smaller values of CLEARVALUE will clear the screen more often  */
/* Suggest to keep it between 32700 and 32767 (it's a signed int) */
#define CLEARVALUE 32500 /* 32750 */

main()
{
  int  x;   /* current x pixel location    */
  int  y;   /* current y pixel location    */
  int  c;   /* current color               */
  int  n;   /* used to drive plotting      */
  int  w;
  int  l;   /* while true keep looping     */
  char k;   /* byte read from the keyboard */
  int  p;   /* number of passes            */
  int  q;   /* pass trigger */
      
  printf("\n\nPress X to exit the program\n\n");
  
  srand(0);  /* randomize the rand() root */
  dzopen();  /* enable the dazzler        */

  /* and now we do something */
  x=rand() % 32;  /* 0 to 31 or 32 positions */
  y=rand() % 32;  /* 0 to 31 or 32 positions */
  c=(rand() % 8) + 8;

  dzbackground(c & 0x07);

  l = 1; /* loop until X is pressed */
  p = 0; /* we haven't plotted a pixel yet */
  q = 3;
  do
  {
    if (p == 0)
    {
      w = rand();
      n = w % 6;
    }
    p++;
    if (p == q)
    {
      p = 0;
      if (w > CLEARVALUE)
      {
        dzbackground(c & 0x07); /* dzclear(); */
      }
    }

    switch(n)
    {
      case 0: x++; break;
      case 1: x--; break;
      case 2: y++; break;
      case 3: y--; break;
      case 4: c++; break;
      case 5: c--; break;
    }

    x &= 0x1F;  /* if (x>31) x=31; */
    /* if (x< 0) x= 0; */
    y &= 0x1F;  /* if (y>31) y=31; */
    /* if (y< 0) y= 0; */
    if (c>15) c=(rand() % 8) + 8;
    if (c< 8) c=(rand() % 8) + 8;
/*  if (c>15) c=(rand() % 16);  */
/*  if (c< 0) c=(rand() % 16);  */
    dzsetpixel(   x,   y,c);  /* upper left  quad */
    dzsetpixel(63-x,63-y,c);  /* lower right quad */
    dzsetpixel(63-x,   y,c);  /* lower left  quad */
    dzsetpixel(   x,63-y,c);  /* upper right quad */

    if (kbhit())
    {
      k = getchar();
      if ((k == 'x') || (k == 'X')) { l=0; }
      if (k == '[')
      {
        q--;
        if (q < 3) { q = 3; }
        printf("q = %d\n",q);
        dzbackground(c & 0x07); /* dzclear(); */
        p = 0;        
      }
      if (k == ']')
      {
        q++;
        if (q > 10) { q = 10; }
        printf("q = %d\n",q);
        dzbackground(c & 0x07); /* dzclear(); */
        p = 0;
      }
      
    }

  }
  while(l);

  dzclose();
}


