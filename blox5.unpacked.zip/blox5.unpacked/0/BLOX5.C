#include <stdio.h>
#include "dazzler.h"
#include "VT100.H"

/*
  Build with:
    cc blox5
    clink blox5 dazzler vt100
  If the dazzler or vt100 CRL files are missing build them with
    cc dazzler.c
    cc vt100.c
*/

/* Smaller values of CLEARVALUE will clear the screen more often  */
/* Suggest to keep it between 32700 and 32767 (it's a signed int) */
#define CLEARVALUE 32755

main()
{
  int  x;   /* current x pixel location */
  int  y;   /* current y pixel location */
  int  c;   /* current color            */
  int  n;   /* used to drive plotting   */
  int s1;   /* used to set the random seed */
  int s2;
  int s3;
  char k;   /* used to get a character from the keyboard */
  int  l;   /* true equals keep running */  
  int cm;   /* color mask used to control background colors */ 
  /* implements the "better quality" generator from page 48 */
  /* get some hopefully somewhat random values from memory  */
  s1 = (peek(126) * 256) + peek(451);
  s2 = (peek(785) * 256) + peek(261);
  s3 = (peek(671) * 256) + peek(456);
  /* Allow colored backgrounds */
  cm = 0x0F;
  
  cls();  /* clear the screen & home the cursor */
  sAttrib(RESET);
  sColor(GREEN);
  printf("Welcome to Blox 5\n\n");
  sAttrib(RESET);
  printf("While running press\n");
  printf("  x to exit the program\n");
  printf("  c to clear the screen and allow colored backgrounds\n");
  printf("  b to clear the screen and force a black background\n\n"); 
  
  /* randomize the initial root */
  nrand(-1,s1,s2,s3);
  /* now randomize the random root based on user interaction */
  nrand(0,"Please wait a bit then press ENTER\n");
  getchar(); /* must manually remove the ENTER from the buffer */
  
  l = 1;  /* loop flag, will keep looping until set to false */
  
  dzopen();  /* enable the dazzler */

  /* and now we do something */
  x=nrand(1)  % 32;  /* 0 to 31 or 32 positions */
  y=nrand(1)  % 32;  /* 0 to 31 or 32 positions */
  c=(nrand(1) % 8) + 8;

  dzbackground(c & 0x07);
  do
  {
    n = nrand(1);
    if (n > CLEARVALUE)
    {
      dzbackground((c & 0x07) & cm); /* cm will allow or block color */
    }
    
    n = n % 6;
    switch(n)
    {
      case 0: x++; break;
      case 1: x--; break;
      case 2: y++; break;
      case 3: y--; break;
      case 4: c++; break;
      case 5: c--; break;
    }
    x &= 0x1F;  /* if (x>31) x=31; */
    /* if (x< 0) x= 0; */
    y &= 0x1F;  /* if (y>31) y=31; */
    /* if (y< 0) y= 0; */
    if (c>15) c=(rand() % 8) + 8;
    if (c< 8) c=(rand() % 8) + 8;
/*  if (c>15) c=(rand() % 16);  */
/*  if (c< 0) c=(rand() % 16);  */
    dzsetpixel(   x,   y,c);  /* upper left  quad */
    dzsetpixel(63-x,63-y,c);  /* lower right quad */
    dzsetpixel(63-x,   y,c);  /* lower left  quad */
    dzsetpixel(   x,63-y,c);  /* upper right quad */
    if (kbhit())
    {
      k = getchar();
      if ((k == 'c') || (k == 'C'))
      {
        cm = 0x0F;
        dzbackground((c & 0x07) & cm); /* dzclear(); */
      }
      if ((k == 'b') || (k == 'B'))
      {
        cm = 0x00;
        dzclear();
      }

      if ((k == 'x') || (k == 'X'))
      {
        l = 0;
      }      
    }
  }
  while(l);

  dzclose();

  printf("\n\nSo long and thanks for flying Dazzler airlines!\n\n");
}


