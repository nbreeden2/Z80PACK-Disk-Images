/* Dazzler library for 64x64 16 color */
/*  0, 0 is the upper left corner
 * 63,63 is the lower right corner
 */
#include "dazzler.h"

int    dzall;     /* Pointer to the alloc()ed area                */
int    dzram;     /* Pointer to the memory the DAZZLER will use   */
char  *dzptr;     /* char pointer to the dazzler memory area      */
short  dzcontrol; /* Enable the DZ and point it at the RAM to use */
short  dzmode;    /* The mode for the dazzler                     */

int dzopen()
{
  int x;
  int y;
  int xo;
  int yo;
  
  dzall  = alloc(2048+512+1); /* allocate memory for the dazzler */
  dzram  = dzall;             /* assign to working variable */
  dzram &= 0xFE00;            /* LS bits must be zeros */
  dzram += 0x0200;            /* move up 512 bytes to get back into */
                              /*  the alloc()ed memory */
  dzptr  = dzram;             /* char * to the RAM the dazzler uses */
  dzcontrol = dzram / 512;    /* shift 9 bits to the right */
  dzcontrol |= 0x80;          /* D7=1=Enable Dazzler       */
  dzmode = 0x3f;              /* 0b00111111 */
  /* 7=0=not used
   * 6=0=normal res
   * 5=1=2K
   * 4=1=color
   * 3=1=high intensity
   * 2=1=blue enabled
   * 1=1=green enabled
   * 0=1=red enabled
  */
  outp(DZMODE,dzmode);        /* Set the mode */
  outp(DZCONTROL,dzcontrol);  /* Set address and enable */
  dzclear();                  /* clear the dazzler ram */


  return(dzram);              /* return the address of the ram root */
}

dzclose()  /* disable the dazzler and free the RAM */
{
  dzclear();
  outp(DZCONTROL,0x00);
  free(dzram);
}

dzspixeln(dzx,dzy,dzc)
int dzx;
int dzy;
int dzc;
{
  if (dzx <  0) return;
  if (dzx > 63) return;
  if (dzy <  0) return;
  if (dzy > 63) return;
  dzsetpixel(dzx,dzy,dzc);  
}

dzsetpixel(dzx,dzy,dzc)  /* set a pixel at dzx,dzy to color dzc */
int dzx;
int dzy;
int dzc;
{
  int     p;
  char   *i;  
  short   v;
  int    xo;  /* offset to 2nd x page */
  int    yo;  /* offset to 2nd y page */

  /* No error checking is done, specifying a pixel location */
  /*    > then 63 will have unpredictable results           */
  /* Deal with the other 512 byte pages - see dazzler docs  */
  xo = 0;
  if (dzx > 31)
  {
    dzx -= 32;
    xo   = 512;
  }
  yo = 0;
  if (dzy > 31)
  {
    dzy -= 32;
    yo   = 1024;
  }  
  
  p = dzram;        /* point at start of Dazzler RAM */
  p += (dzx / 2);   /* 8 bytes is 16 pixels */
  p += (dzy * 16);  /* 16 bytes per line in each quadrent */
  i = p + xo + yo;

  v = *i;         /* get the current colors */

  if (dzx & 1)     /* LS nibble */ 
  {
    v &= 0x0F;
    v += (dzc * 16);
    *i = v;  
  }
  else /* MS nibble */  
  {
    v &= 0xF0;
    v += dzc;
    *i = v;
  }
}

int dzgetpixel(dzx,dzy)  /* get the pixel color at dzx,dzy */
int dzx;
int dzy;
{
  int     p;
  char   *i;  
  short   v;
  int    xo;  /* offset to 2nd x page */
  int    yo;  /* offset to 2nd y page */

  /* No error checking is done, specifying a pixel location */
  /*    > then 63 will have unpredictable results           */
  /* Deal with the other 512 byte pages - see dazzler docs  */
  xo = 0;
  if (dzx > 31)
  {
    dzx -= 32;
    xo   = 512;
  }
  yo = 0;
  if (dzy > 31)
  {
    dzy -= 32;
    yo   = 1024;
  }  
  
  p = dzram;        /* point at start of Dazzler RAM */
  p += (dzx / 2);   /* 8 bytes is 16 pixels */
  p += (dzy * 16);  /* 16 bytes per line in each quadrent */
  i = p + xo + yo;

  v = *i;         /* get the current colors */

  if (dzx & 1)     /* LS nibble */ 
  {
    v &= 0x0F;
    return(v);
  }
  else /* MS nibble */  
  {
    v &= 0xF0;
    return(v / 16);
  }
}

dzclear()
{
/*  int *p;
  for (p=dzram; p<dzram+2048; ++p)
  {
    *p=0;
  }
*/
  setmem(dzptr,2048,0);
}

dzbackground(c)
char c;
{
/*  char *p;
  c = (c * 16) + c;
  for (p=dzram; p<dzram+2048; ++p)
  {
    *p=c;
  }
*/
  c = (c * 16) + c;  /* gotta write both nibbles */
  setmem(dzptr,2048,c);
}

dzhline(xstart,xstop,y,color)
int xstart;
int xstop;
int y;
int color;
{
  int x;
  if (xstart > xstop) return;
  if (xstart > 63)    return;
  if (xstart <  0)    return;
  if (y      > 63)    return;
  if (y      <  0)    return;   
  for (x=xstart; x<=xstop; x++)
  {
    dzsetpixel(x,y,color);
  }
}

dzvline(x,ystart,ystop,color)
int x;
int ystart;
int ystop;
int color;
{
  int y;
  if (ystart > ystop) return;
  if (ystart > 63)    return;
  if (ystart <  0)    return;
  if (x      > 63)    return;
  if (x      <  0)    return;   
  for (y=ystart; y<=ystop; y++)
  {
    dzsetpixel(x,y,color);
  }
}

dzbox(xstart,xstop,ystart,ystop,c)
int xstart;
int xstop;
int ystart;
int ystop;
int c;
{
    /*         x     x      y c  */
  dzhline(xstart,xstop,ystart,c);
  dzhline(xstart,xstop,ystop ,c);
    /*         x      y     y c  */
  dzvline(xstart,ystart,ystop,c);
  dzvline(xstop ,ystart,ystop,c);
}

dzboxfill(xstart,xstop,ystart,ystop,c)
int xstart;
int xstop;
int ystart;
int ystop;
int c;
{
  int x;
  
  for (x=xstart;x<=xstop;++x)
  {
    dzvline(x,ystart,ystop,c);    
  }
}

dzline(x0,y0,x1,y1,c)
int x0;
int y0;
int x1;
int y1;
int  c;
{
  int dx;
  int dy;
  int err;
  int sx;
  int sy;
  int e2;
  
  dx  =  abs (x1 - x0);
  sx  =  x0 < x1 ? 1 : -1;
  dy  = -abs (y1 - y0);
  sy  =  y0 < y1 ? 1 : -1; 
  err = dx + dy;
  e2  = 0; /* error value e_xy */
       
  for (;;)
  {  /* loop */
    dzsetpixel (x0,y0,c);
    if ((x0 == x1) && (y0 == y1)) break;
    e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; } /* e_xy+e_x > 0 */
    if (e2 <= dx) { err += dx; y0 += sy; } /* e_xy+e_y < 0 */
  }
}

dzcircle(xm,ym,r,c)
int xm;
int ym;
int r;
int c;
{
  int x;
  int y;
  int err;
  
  x   = -r;
  y   =  0;
  err =  2-2*r; /* II. Quadrant */ 
  do 
  {
    dzspixeln(xm-x, ym+y, c); /*   I. Quadrant */
    dzspixeln(xm-y, ym-x, c); /*  II. Quadrant */
    dzspixeln(xm+x, ym-y, c); /* III. Quadrant */
    dzspixeln(xm+y, ym+x, c); /*  IV. Quadrant */
    r = err;
    if (r >  x) err += ++x*2+1; /* e_xy+e_x > 0 */
    if (r <= y) err += ++y*2+1; /* e_xy+e_y < 0 */
  } 
  while (x < 0);
}


