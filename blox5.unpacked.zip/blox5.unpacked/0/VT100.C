/* VT100.C
 * Source code file to setup defines and functions 
 *   for managing a VT100/VT132/S-132 terminals.
 * Includes defintions that are not VT100 specific
 *   for later terminals in the VTxxx series. 
 * V1.1b June 19, 2023 - NBBII 
 * https://thehighnibble.com/vt132/
 */

#include "VT100.H"

/* used in vt100.h - left as global for speed */
char strVT100[15];
/* can be accessed by the application */
char PosVT100[50];
char StatVT100[50];
char TermVT100[50];
char AttrVT100[50];

gPosition()
{
  sprintf(strVT100,"%c[6n",0x1B);
  puts(strVT100); 
  scanf("%s",PosVT100); 
  printf("\nPosition:%s\n",PosVT100);
}

gStatus()
{
  sprintf(strVT100,"%c[5n",0x1B);
  puts(strVT100); 
  gets(StatVT100); 
  printf("\nStatus:%s\n",StatVT100);
}

gTerm()
{
  sprintf(strVT100,"%cZ",0x1B);
  puts(strVT100); 
  gets(TermVT100); 
  printf("\nTerm:%s\n",TermVT100);
}

gAttributes()
{
  sprintf(strVT100,"%cc",0x1B);
  puts(strVT100); 
  gets(AttrVT100); 
  printf("\nAttr:%s\n",AttrVT100);
}

/*#ifdef VT100DBG
char *VT100CLR[8];
initPtr(VT100CLR,"Black","Red"    ,"Green","Yellow",
                 "Blue" ,"Magenta","Cyan" ,"White" ,NULL);
#endif*/

/* Can be used to add a delay after commands are sent to the terminal */
/* The function calls for this have been commented out */
/* Will be removed in a future version */
/*
#ifndef VTDELAY
#define VTDELAY 0
#endif
*/

/* set both the foreground and background color */
sColors(fg,bg)
int fg,bg;
{
  sprintf(strVT100,"%c[%1d;%1dm",0x1B,fg,bg+BG);
  puts(strVT100);
  /*sleep(VTDELAY);*/
}

/* set any color */
sColor(clr)
int clr;
{
  sprintf(strVT100,"%c[%1dm",0x1B,clr);
  puts(strVT100);
  /*sleep(VTDELAY);*/
}

/* set character attributes 0 thru 29 */
sAttrib(at)
int at;
{
  if (at<=9) /* at=0..8 are character attributes, BOLD, BLINK etc. */
  {
    sprintf(strVT100,"%c[%1dm",0x1B,at);
    puts(strVT100);
    /*sleep(VTDELAY);*/
    return;
  }
  if (at<=29) /* at=10..29 are character attributes, BOLD, BLINK etc. */
  {
    sprintf(strVT100,"%c[%2dm",0x1B,at);
    puts(strVT100);
    /*sleep(VTDELAY);*/
    return;
  }

  switch(at) /* at > 29 are terminal attributes */
  {
    case COL132:  sprintf(strVT100,"%c[?3h",0x1B);  break;
    case COL80:   sprintf(strVT100,"%c[?3l",0x1B);  break;
    case ENACOL:  sprintf(strVT100,"%c[?40h",0x1B); break;
    case DISCOL:  sprintf(strVT100,"%c[?40l",0x1B); break;
    case DWSH:    sprintf(strVT100,"%c#6",0x1B);    break;
    case SWSH:    sprintf(strVT100,"%c#5",0x1B);    break;
    case DHTOP:   sprintf(strVT100,"%c#3",0x1B);    break;
    case DHBOT:   sprintf(strVT100,"%c#4",0x1B);    break;
    case UKG0:    sprintf(strVT100,"%c(A",0x1B);    break;
    case UKG1:    sprintf(strVT100,"%c)A",0x1B);    break;
    case USG0:    sprintf(strVT100,"%c(B",0x1B);    break;
    case USG1:    sprintf(strVT100,"%c)B",0x1B);    break;
    case G0SPEC:  sprintf(strVT100,"%c(0",0x1B);    break;
    case G1SPEC:  sprintf(strVT100,"%c)0",0x1B);    break;
    case G0ALT:   sprintf(strVT100,"%c(1",0x1B);    break;
    case G1ALT:   sprintf(strVT100,"%c)1",0x1B);    break;
    case G0ROM:   sprintf(strVT100,"%c(2",0x1B);    break;
    case G1ROM:   sprintf(strVT100,"%c)2",0x1B);    break;
    case BGRESET: sprintf(strVT100,"%c[49m",0x1B);  break;
    case LOFF:    sprintf(strVT100,"%c[0q",0x1B);   break;
    case L1ON:    sprintf(strVT100,"%c[1q",0x1B);   break;
    case L2ON:    sprintf(strVT100,"%c[2q",0x1B);   break;
    case L3ON:    sprintf(strVT100,"%c[3q",0x1B);   break;
    case L4ON:    sprintf(strVT100,"%c[4q",0x1B);   break;
    case L1OFF:   sprintf(strVT100,"%c[21q",0x1B);  break;
    case L2OFF:   sprintf(strVT100,"%c[22q",0x1B);  break;
    case L3OFF:   sprintf(strVT100,"%c[23q",0x1B);  break;
    case L4OFF:   sprintf(strVT100,"%c[24q",0x1B);  break;
    case SMOOTH:  sprintf(strVT100,"%c[?4h",0x1B);  break;
    case JUMP:    sprintf(strVT100,"%c[?4l",0x1B);  break;
    default:      return;  /* unknown setting so return */
  }
  puts(strVT100);
  /*sleep(VTDELAY);*/
}

/* position the cursor */
positionCursor(row,col)
int row, col;
{
  sprintf(strVT100,"%c[%1d;%1dH",0x1B,row,col);
  puts(strVT100);
  /*sleep(VTDELAY);*/
}

/* clear screen */
clearScreen()
{
  bios(4,0x1B);
  puts("[2J");
  /*sleep(VTDELAY);*/
}

/* Home cursor to 1,1 */
homeCursor()
{
   bios(4,0x1B);
   puts("[H");
   sleep(1);
}

/* clear the screen and home the cursor */
cls()
{
  clearScreen();
  homeCursor();
}

/* Tell VT100 to change to AUX output.  */
/* Output to the VT100 is still parsed  */
/*  by the VT100 but is sent to the aux */
/*  port on the VT100 instead of too    */
/*  the screen.                         */
auxOn(delay)
int delay;
{
  printf("%c[?38h",27);   /* <ESC>[?38h */
  if (delay > 0) sleep(delay);
}

/* Tell VT100 to change to AUX off      */
auxOff(delay)
int delay;
{
  printf("%c%c",27,03);   /* <ESC><ETX> */
  if (delay > 0) sleep(delay);
}

/* used for debugging and demos */
#ifdef VT100DBG
pColor(clr)
int clr;
{
  switch(clr){
    case BLACK:   printf("Black");   break;
    case RED:     printf("Red");     break;
    case GREEN:   printf("Green");   break;
    case YELLOW:  printf("Yellow");  break;
    case BLUE:    printf("Blue");    break;
    case MAGENTA: printf("Magenta"); break;
    case CYAN:    printf("Cyan");    break;
    case WHITE:   printf("White");   break;
  }
}

pAttrib(att)
int att;
{
  switch(att){
    case RESET:      printf("Reset     "); break;
    case BOLD:       printf("Bold      "); break;
    case DIM:        printf("Dim       "); break;
    case ITALIC:     printf("Italic    "); break;
    case UNDERSCORE: printf("Underline "); break;
    case BLINK:      printf("Blink     "); break;
    case REVERSE:    printf("Reverse   "); break;
    case HIDDEN:     printf("Hidden    "); break;
    case UKG0:       printf("UK G0     "); break;
    case UKG1:       printf("UK G1     "); break;
    case USG0:       printf("US G0     "); break;
    case USG1:       printf("US G1     "); break;
    case G0SPEC:     printf("G0 Spec   "); break;
    case G1SPEC:     printf("G1 Spec   "); break;
    case G0ALT:      printf("G0 Alt    "); break;
    case G1ALT:      printf("G1 Alt    "); break;
    case G0ROM:      printf("G0 ROM    "); break;
    case G1ROM:      printf("G1 ROM    "); break;
    case BGRESET:    printf("BGReset   "); break;
    case LOFF:       printf("LEDs Off  "); break;
    case L1ON:       printf("LED 1 On  "); break;
    case L2ON:       printf("LED 2 On  "); break;
    case L3ON:       printf("LED 3 On  "); break;
    case L4ON:       printf("LED 4 On  "); break;
    case L1OFF:      printf("LED 1 Off "); break;
    case L2OFF:      printf("LED 2 Off "); break;
    case L3OFF:      printf("LED 3 Off "); break;
    case L4OFF:      printf("LED 4 Off "); break;
  }
}
#endif

